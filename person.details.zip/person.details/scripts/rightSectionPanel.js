var rsp = {};

rsp.createChildren = function() {
    person.createChildren();
    address.createChildren();
}
rsp.createView = function(){
    person.createView();
    address.createView();
}
rsp.prepopulate = function(){
    person.prepopulate();
    address.prepopulate();
}

rsp.listenEvents = function() {
    // eventManager.subscribe('personSelected', rsp.onPersonSelected);
    personPanel.listenEvents ();
    addressPanel.listenEvents();
}

rsp.onPersonSelect = function() {
    
}