function createAddressPanel() {
    createAddressListPanel();
    createAddressInfoPanel();
}