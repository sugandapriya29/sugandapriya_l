var service = {};

service.loadPersonData = function () {
    getJSON('data/emp.json', function (data) {
        service.constructPersonTable(data);
        empDetails.getData(data);
   });
}

service.constructPersonTable = function (data) {
    for (var index = 0; index < data.users.length; index++) {
        empList.displayPersonTable(data.users[index],index);

  }
}
