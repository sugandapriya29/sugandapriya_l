var lsp = {};

lsp.createChildren = function() { }

lsp.createView = function() {
      var httpRequest = new XMLHttpRequest();
    httpRequest.onreadystatechange = function(){
    if (this.readyState === 4 && this.setStatus === 200){
        document.getElementById('sidenav').innerHTML = this.responseText;
    }
  };
  
    httpRequest.open('GET', 'leftSectionPanel.html', true);
    httpRequest.send();
}

lsp.prepopulate = function() {}

lsp.listenEvents = function() {
    document.getElementById('person').addEventListener('click',
        function(event) {
            eventManager.broadcast('personSelected', 'onPersonSelect');
      }
    )
    document.getElementById('address').addEventListener('click',
        function(event) {
            eventManager.broadcast('addressSelected', 'onAddressSelect');
      }
    )
};

lsp.personClick = function() {
    eventManager.broadcast('personSelected','person');
}
