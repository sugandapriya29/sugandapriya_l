var eventManager = {};

eventManager.subscribers = [];

eventManager.subscribe = function(event, listener) {
    eventManager.subscribers[click] = listener;
  
}

eventManager.broadcast = function(event, data) {
    var listen = eventManager.subscribers[click];
    listen(data);
}
