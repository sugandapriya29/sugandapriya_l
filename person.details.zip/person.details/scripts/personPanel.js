var person = { };

person.createChildren = function() {
    personList.createChildren();
    personInfo.createChildren();
   
}

person.createView = function() {
    personList.createView();
    personInfo.createView();
}

person.prepopulatePersonPanel = function() {
    personList.prepopulatePersonPanel();
    personInfo.prepopulatePersonPanel();
}

person.listenEvents = function() {
    personList.listenEvents();
    personInfo.listenEvents();
}

person.setDefault = function() {
    personList.setDefault();
    personInfo.setDefault();
}